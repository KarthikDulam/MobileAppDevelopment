//
//  MyCell.swift
//  Filterer
//
//  Created by Maslov Sergey on 27.11.15.
//  Copyright © 2015 UofT. All rights reserved.
//

import UIKit

class MyCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!

}
